Asko-DOT Chatbot

Welcome to Asko-DOT Chatbot, a simple and interactive chatbot for your conversations!

Installation:

Windows:

1. Download the Asko-DOT Chatbot Installer:
   

2. Run the Installer:
   - Execute the downloaded .exe file and follow the on-screen instructions to install Asko-DOT Chatbot.

3. Launch Asko-DOT:
   - After installation, launch Asko-DOT and start chatting!

Linux:

1. Download the Asko-DOT Chatbot ZIP file:
  

2. Extract the ZIP File:
   - Use your preferred file manager or the following command to extract the contents of the downloaded ZIP file:
     ```
     unzip Asko-DOT-Linux.zip
     ```

3. Navigate to the Asko-DOT Directory:
   - Change into the Asko-DOT directory using the following command:
     ```
     cd Asko-DOT-Linux
     ```

4. Make Asko_run.sh Executable:
   - Ensure that the Asko_run.sh script is executable. If not, make it executable using the following command:
     ```
     chmod +x Asko_run.sh
     ```

5. Run Asko-DOT Chatbot:
   - Execute the Asko_run.sh script to launch the chatbot:
     ```
     ./Asko_run.sh
     ```

6. Start Chatting:
   - Asko-DOT Chatbot should now be running. Start interacting with the chatbot by typing your messages.

Note: If you encounter any issues or have questions, feel free to report them to skyking5256@gmail.com.

Enjoy chatting with Asko-DOT!

Usage:

1. Starting a Conversation:
   - Launch Asko-DOT Chatbot and type your messages in the input area.

2. Training the Chatbot:
   - If you want to train the chatbot with new responses, use the 'Train Chatbot' feature.

3. Exiting the Chatbot:
   - Type 'exit' to end the conversation and close Asko-DOT.
