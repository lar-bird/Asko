#!/bin/bash

# Set the working directory to the script's location
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Java is not installed. Please install Java to run this application."
    exit 1
fi

# Check if the JAR file exists
JAR_FILE="Dot 1.0.jar"
if [ ! -f "$JAR_FILE" ]; then
    echo "Error: $JAR_FILE not found. Make sure the JAR file is in the same directory as this script."
    exit 1
fi

# Run the Java application
java -jar "$JAR_FILE" "$@"
